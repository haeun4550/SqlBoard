package com.haeun.sql.util;

public class Var {
	public static String nowId;
	public static String nowPw;
	public static boolean flag = true;
	

}
