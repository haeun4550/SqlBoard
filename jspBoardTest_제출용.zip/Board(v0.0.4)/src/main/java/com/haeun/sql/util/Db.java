package com.haeun.sql.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Db {
	public static Connection con = null;
	public static Statement st = null;
	public static ResultSet result = null;
	public static int pageNum;
	public static int reNum;
	public static String cmdSearch;
	static private String DB_NAME = "my_dog";
	static private String DB_ID = "root";
	static private String DB_PW = "0000";
	static public String tableNameBoard = "board";
	static public String tableNameReply = "reply";
	static public String tableNameJoin = "join_member";
	public String n;
	public String title;
	public String id;
	public String content;
	public String count;
	public String dt;
	public String recommend;
	public String hit;
	public String re_id;
	public String re_content;
	public String reportCnt;
	public String reportCon;
	public String dbCount;
	public String reportOption;
	public String password;
	public String joinApprove;
	public String recommendUse;
	public String recommendUser;
	public String usedRecommend;
	
	public int postNum;
	

	public void dbConnect() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + DB_NAME, DB_ID, DB_PW);
			st = con.createStatement();
		} catch (Exception e) {

		}
	}

	public void dbClose() {
		try {
			st.close();
			con.close();
			result.close();
		} catch (Exception e) {

		}
	}
	
	public int dbCount() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			dbConnect();
			result = st.executeQuery("select count(*) from memberBoard");
			result.next();
			int count = Integer.parseInt(result.getString("count(*)"));
			return count;
		} catch (Exception e) {
			e.printStackTrace();
		}
		dbClose();
		return 0;
	}
	
	public int dbSearchCount(String query) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			dbConnect();
			result = st.executeQuery(query);
			result.next();
			int count = Integer.parseInt(result.getString("count(*)"));
			return count;
		} catch (Exception e) {
			e.printStackTrace();
		}
		dbClose();
		return 0;
	}
	
	
	public void dbExecuteQueryForRead(String query) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			dbConnect();
			result = st.executeQuery(query);
			while (result.next()) {
				n = result.getString("n");
				title = result.getString("title");
				content = result.getString("content");
				id = result.getString("id");
				recommend = result.getString("recommend");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		dbClose();
	}

	public ArrayList<Post> dbExecuteQueryForList(String query) {
		ArrayList<Post> posts = new ArrayList<>();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			dbConnect();
			result = st.executeQuery(query);
			while (result.next()) {
				n = result.getString("n");
				title = result.getString("title");
				id = result.getString("id");
				content = result.getString("content");
				dt = result.getString("dt");
				recommend = result.getString("recommend");
				hit = result.getString("hit");
				reportCnt = result.getString("reportCnt");
				reportCon = result.getString("reportCon");
				reportOption = result.getString("reportOption");
				posts.add(new Post(n, title, content, id, dt, recommend, hit, reportCnt, reportCon, reportOption));
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("SQLException " + e.getMessage());
		}
		dbClose();
		return posts;
	}
	
 
	
	
	public ArrayList<Reply> dbSelectReply(String query) {
		ArrayList<Reply> reply = new ArrayList<>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			dbConnect();
			result = st.executeQuery(query);
			while (result.next()) {
				re_content = result.getString("re_content");
//				postNum= Integer.parseInt(result.getString("postNum"));
				re_id = result.getString("re_id");
				reply.add(new Reply(re_id, re_content));
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		dbClose();
		return reply;
	}
	
	public ArrayList<Report> dbSelectReport(String query) {
		ArrayList<Report> report = new ArrayList<>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			dbConnect();
			result = st.executeQuery(query);
			while (result.next()) {
				reportOption = result.getString("reportOption");
				System.out.println(reportOption);
//				postNum= Integer.parseInt(result.getString("postNum"));
				reportCon = result.getString("reportCon");
				System.out.println(reportCon);
				report.add(new Report(reportOption, reportCon));
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		dbClose();
		return report;
	}
	
	public ArrayList<Member> dbSelectMember(String query) {
		ArrayList<Member> members = new ArrayList<>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			dbConnect();
			result = st.executeQuery(query);
			while (result.next()) {
				id = result.getString("id");
				password = result.getString("password");
				reportCnt = result.getString("reportCnt");
				joinApprove = result.getString("joinApprove");
				recommendUse = result.getString("recommendUse");
				members.add(new Member(id, password, joinApprove, reportCnt, recommendUse));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		dbClose();
		return members;
	}	

	public void dbUpdate(String query) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			dbConnect();
			int resultCount = st.executeUpdate(query);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("SQLException " + e.getMessage());
		}
		dbClose();
	}
	
	public void dbLogin(String query) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			dbConnect();
			result = st.executeQuery(query);
			}
		 catch (Exception e) {
			e.printStackTrace();
		}
		dbClose();
	}
	
	public void dbSelect(String query) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			dbConnect();
			result = st.executeQuery(query);
			result.next();
			n = result.getString("n");
			title = result.getString("title");
			id = result.getString("id");
			content = result.getString("content");
			dt = result.getString("dt");
			recommend = result.getString("recommend");
			hit = result.getString("hit");
			reportCnt = result.getString("reportCnt");
			reportCon = result.getString("reportCon");
			}
		 catch (Exception e) {
			e.printStackTrace();
		}
		dbClose();
	}
	public void dbMemberSelect(String query) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			dbConnect();
			result = st.executeQuery(query);
			result.next();
			n = result.getString("n");
			id = result.getString("id");
			password = result.getString("password");
			reportCnt = result.getString("reportCnt");
			joinApprove = result.getString("joinApprove");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		dbClose();
	}
	
	public void dbRecommendSelect(String query) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			dbConnect();
			result = st.executeQuery(query);
			result.next();
			recommendUser = result.getString("recommendUser");
			usedRecommend = result.getString("usedRecommend");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		dbClose();
	}
	
}

