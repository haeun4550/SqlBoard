package com.haeun.sql.util;

public class Post {
	public String n;
	public String title;
	public String content;
	public String id;
	public String dt;
	public String recommend;
	public String hit;
	public String reportCnt;
	public String reportCon;
	public String reportOption;
	
	
	public Post(String n, String title, String content, String id,
			String dt, String recommend, String hit, String reportCnt, String reportCon, String reportOption) {
		super();
		this.n = n;
		this.title = title;
		this.content = content;
		this.id = id;
		this.dt = dt;
		this.recommend = recommend;
		this.hit = hit;
		this.reportCnt=reportCnt;
		this.reportCon=reportCon;
		this.reportOption=reportOption;
	}
	
	
}
