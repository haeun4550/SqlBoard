package com.haeun.sql.util;

public class Reply {
	public String re_id;
	public String re_content;
	public int postNum;
	
	public Reply(String re_id, String re_content) {
		super();
		this.re_id=re_id;
		this.re_content=re_content;
	}
}
