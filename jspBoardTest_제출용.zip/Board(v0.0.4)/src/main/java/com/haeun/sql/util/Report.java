package com.haeun.sql.util;

public class Report {
	public String reportOption;
	public String reportCnt;
	public String reportCon;
	public int postNum;

	public Report(String reportOption, String reportCon) {
		super();
		this.reportOption = reportOption;
		this.reportCon = reportCon;
	}
}
