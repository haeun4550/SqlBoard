package com.haeun.sql.util;

public class Member {
		public String id;
		public String password;
		public String joinApprove;
		public String reportCnt;
		public String recommendUse;
		
		public Member(String id, String password, String joinApprove, String reportCnt, String recommendUse){
			super();
			this.id=id;
			this.password=password;
			this.joinApprove=joinApprove;
			this.reportCnt=reportCnt;
			this.recommendUse=recommendUse;
		}
}
