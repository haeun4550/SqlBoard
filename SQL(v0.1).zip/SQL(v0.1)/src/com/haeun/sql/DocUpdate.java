package com.haeun.sql;

public class DocUpdate {
	public static void run() {
		System.out.println("수정할 글번호를 입력해주세요.");
		String n = ProcBoard.sc.next();
		loop:
			while(true) {
		System.out.println("수정할 항목을 선택해주세요. [1.제목/2.내용/3.작성자/e.수정종료]");
		String cmd = ProcBoard.sc.next();
			switch(cmd) {
			case "1":
				ProcBoard.sc.nextLine();
				System.out.println("수정할 내용 입력");
				String title = ProcBoard.sc.nextLine();
				ProcBoard.dbExecuteUpdate("update board set title='"+title+"' where n="+n+"");
				System.out.println("수정완료");
				break;
			case "2":
				ProcBoard.sc.nextLine();
				System.out.println("수정할 내용 입력");
				String content = ProcBoard.sc.nextLine();
				ProcBoard.dbExecuteUpdate("update board set content='"+content+"'where n="+n+"");
				System.out.println("수정완료");
				break;
			case "3":
				ProcBoard.sc.nextLine();
				System.out.println("수정할 내용 입력");
				String writer = ProcBoard.sc.nextLine();
				ProcBoard.dbExecuteUpdate("update board set id='"+writer+"'where n="+n+"");
				System.out.println("수정완료");
				break;
			case "e" :
				System.out.println("수정을 종료합니다.");
				break loop;
			}
	}
}
}
