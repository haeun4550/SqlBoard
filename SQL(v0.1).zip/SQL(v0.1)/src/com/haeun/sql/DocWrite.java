package com.haeun.sql;

public class DocWrite {
	public static void run() {
		ProcBoard.sc.nextLine();
		System.out.println("글제목을 입력해주세요");
		String title = ProcBoard.sc.nextLine();
		System.out.println("내용을 입력해주세요");
		String content = ProcBoard.sc.nextLine();
		System.out.println("ID를 입력해주세요");
		String id = ProcBoard.sc.nextLine();
		ProcBoard.dbExecuteUpdate("insert into board(title, id, dt, content, hit) values('"+title+"','"+id+"',now(),'"+content+"',0);");
		System.out.println("작성완료");
	}
}
