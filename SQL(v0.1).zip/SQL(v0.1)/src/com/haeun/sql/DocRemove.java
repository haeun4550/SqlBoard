package com.haeun.sql;

public class DocRemove {
	public static void run() {
		System.out.println("삭제할 글번호를 입력해주세요. (all 입력시 전체삭제)");
		String num = ProcBoard.sc.next();
		if(num.equals("all")) {
			ProcBoard.dbExecuteUpdate("truncate board");
		}
		//		int number = Integer.parseInt(num);
		else{ProcBoard.dbExecuteUpdate("delete from board where n ="+num+"");
		System.out.println("삭제완료");
		}
	}	
}

