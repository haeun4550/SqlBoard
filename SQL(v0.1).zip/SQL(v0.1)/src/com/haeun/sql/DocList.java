package com.haeun.sql;

public class DocList {
	public static void run() {
		System.out.println("글리스트입니다.");
		ProcBoard.dbExecuteQueryForList("select*from board");
	}
}
