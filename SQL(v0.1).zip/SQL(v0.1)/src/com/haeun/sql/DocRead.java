package com.haeun.sql;

public class DocRead {
	public static void run() {
		System.out.println("읽을 글번호를 입력해주세요.");
		String num = ProcBoard.sc.next();
		ProcBoard.dbExecuteQuery("select*from board where n ="+num+"");
	}
}
