package com.haeun.sql;

public class Main {

	public static void main(String[] args) {
		ProcBoard procBoard = new ProcBoard();
		Display.showTitle();
		procBoard.run();
	}
}
