package com.haeun.sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class ProcBoard {
	Connection con = null;
	static Statement st = null;
	static ResultSet result = null;
	static Scanner sc= new Scanner(System.in);
	
	void run() {
		dbInit();
		selectMenu();
	}
	
	private void dbInit() {
		try { 
			//디비 접속 정보 넣어서 접속하기
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_dog", "root", "0000");
			// Statement 객체 얻어오기
			st = con.createStatement();
		}catch(SQLException e){
			System.out.println("SQLException: "+ e.getMessage());
			System.out.println("SQLState: "+ e.getSQLState());
		}
	}
	
	static void dbExecuteQuery(String query) {
		try {
			result = st.executeQuery(query);
			while(result.next()) { //결과를 하나씩 빼기. 더 이상 없으면 false 리턴됨.
				String title = result.getString("title");
				System.out.println("제목: "+title);
				String content = result.getString("content");
				System.out.println("내용: "+content);
				String writer = result.getString("id");
				System.out.println("작성자: "+writer);
				String hit = result.getString("hit");
				System.out.println("조회수: "+hit);
				String dt = result.getString("dt");
				System.out.println(dt);
			}
		}catch(SQLException e){
			System.out.println("SQLException "+ e.getMessage());
			System.out.println("SQLState: "+ e.getSQLState());
		}
	}
	static void dbExecuteQueryForList(String query) {
		try {
			result = st.executeQuery(query);
			while(result.next()) { //결과를 하나씩 빼기. 더 이상 없으면 false 리턴됨.
				String n = result.getString("n");
				System.out.print("글번호:"+n);
				String title = result.getString("title");
				System.out.print(" 제목:"+title);
				String writer = result.getString("id");
				System.out.print(" 작성자:"+writer);
				String hit = result.getString("hit");
				System.out.print(" 조회수:"+hit);
				String dt = result.getString("dt");
				System.out.println(dt);
			}
		}catch(SQLException e){
			System.out.println("SQLException "+ e.getMessage());
			System.out.println("SQLState: "+ e.getSQLState());
		}
	}
	
	static void dbExecuteUpdate(String query) {
		try {
			// Statement 객체의 executeUpdate 함수에 sql문 실어서 디비에서 실행되게 하기
			int resultCount = st.executeUpdate(query); // <<실행하는 순간 디비에 sql(쿼리) 날아감. (디비에 반영됨)
			System.out.println("처리된 행 수:"+ resultCount);
		}catch(SQLException e){
			e.printStackTrace();
			System.out.println("SQLException: "+ e.getMessage());
			System.out.println("SQLState: "+ e.getSQLState());
		}
	}
	
	private void selectMenu() {
		loop:
			while(true) {
				dbPostCount();
				System.out.println("************************************************");
				System.out.println("[1.글쓰기/2.글읽기/3.글삭제/4.글수정/5.글리스트/e.프로그램종료]");
				System.out.println("************************************************");
		String cmd = sc.next();
		switch(cmd) {
		case "1" :
			DocWrite.run();
			break;
		case "2" :
			DocRead.run();
			break;
		case "3" :
			DocRemove.run();
			break;
		case "4" :
			DocUpdate.run();
			break;
		case "5" :
			DocList.run();
			break;
		case "e" :
			System.out.println("프로그램을 종료합니다.");
			break loop;
		default:
			System.out.println("다시입력해주세요.");
		}
			}
	}
	private void dbPostCount() {	
		try {
			result = st.executeQuery("select count(*) from board");
			result.next();
			String count = result.getString("count(*)");
			System.out.println("글 수:"+count);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}