package com.haeun.sqlTest;

import com.haeun.sqlTest.util.Db;
import com.haeun.sqlTest.util.Scan;

public class ProcRead {

	public static void run() {
		if (Db.DocCnt == 0) {
			System.out.println("글이 없습니다.");
			System.out.println("================================================");
		} else {
			System.out.println("=====================글읽기=======================");
			String readNum = Scan.rl("읽을 글번호를 입력해주세요.");
			
			Db.dbExecuteUpdate("update " + Db.tableNameBoard + " set hit=hit+1 where n=" + readNum + "");
			Db.dbExecuteQueryForRead("select*from " + Db.tableNameBoard + " where n= " + readNum + "");
			System.out.println("================================================");
		}
	}
}
