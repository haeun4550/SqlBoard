package com.haeun.sqlTest;

import com.haeun.sqlTest.util.Db;

public class ProcList {

	public static void run() {
		if (Db.DocCnt == 0) {
			System.out.println("글이 없습니다.");
			System.out.println("===========================================");
		} else {
			System.out.println("=================글리스트=====================");
			Db.dbExecuteQueryForList("select*from "+Db.tableNameBoard+"");
			System.out.println("===========================================");
		}
	}
}
