package com.haeun.sqlTest.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Scan {
	static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

	static public String rl(String comment) {
		System.out.println(comment + ":");
		try {
			return reader.readLine();
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
}
