package com.haeun.sqlTest.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Db {
	static Connection con = null;
	static Statement st = null;
	static ResultSet result = null;
	public static int DocCnt;
	static private String DB_NAME = "my_dog";
	static private String DB_ID = "root";
	static private String DB_PW = "0000";
	static public String tableNameBoard = "boardTest";

	public static void dbInit() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+DB_NAME, DB_ID, DB_PW);
			st = con.createStatement();
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
			e.printStackTrace();
		}
	}

	public static void dbExecuteQueryForList(String query) {
		try {
			result = st.executeQuery(query);
			while (result.next()) {

				String num = result.getString("n");
				System.out.print("번호:" + num);
				String title = result.getString("title");
				System.out.print(" 제목:" + title);
				String id = result.getString("id");
				System.out.print(" 작성자:" + id);
				String hit = result.getString("hit");
				System.out.print(" 조회수:" + hit);
				String dt = result.getString("dt");
				System.out.println(" 작성일:" + dt);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public static void dbExecuteQueryForRead(String query) {
		try {
			result = st.executeQuery(query);
			while (result.next()) {
				String title = result.getString("title");
				System.out.print("제목:" + title);
				String id = result.getString("id");
				System.out.print(" 작성자:" + id);
				String hit = result.getString("hit");
				System.out.print(" 조회수:" + hit);
				String dt = result.getString("dt");
				System.out.println(" 작성일:" + dt);
				String content = result.getString("content");
				System.out.println("내용:" + content);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	public static void dbExecuteQuery(String query) {
		try {
			result = st.executeQuery(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void dbExecuteUpdate(String query) {
		try {
			int resultCnt = st.executeUpdate(query);

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}

	public static void dbExecuteCount() {
		try {
			result = st.executeQuery("select count(n) from "+tableNameBoard+"");
			result.next();
			DocCnt = Integer.parseInt(result.getString("count(n)"));
			System.out.println("전체글수:" + DocCnt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
