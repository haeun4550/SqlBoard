package com.haeun.sqlTest;

import com.haeun.sqlTest.util.Db;
import com.haeun.sqlTest.util.Scan;

public class ProcWrite {
	static String id;
	static String title;
	static String content;

	public static void run() {
		System.out.println("===================글쓰기페이지===================");
		id = Scan.rl("글쓴이를 입력해주세요");
		title = Scan.rl("제목을 입력해주세요");
		content = Scan.rl("내용을 입력해주세요");

		Db.dbExecuteUpdate("insert into "+Db.tableNameBoard+"(id,title,content,dt,hit) values ('" + id + "', '" + title + "', '"
				+ content + "', now(), 0)");
		System.out.println("작성완료");
		System.out.println("==============================================");
	}

}
