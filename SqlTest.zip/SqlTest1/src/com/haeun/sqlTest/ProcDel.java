package com.haeun.sqlTest;

import com.haeun.sqlTest.util.Db;
import com.haeun.sqlTest.util.Scan;

public class ProcDel {

	public static void run() {
		if (Db.DocCnt == 0) {
			System.out.println("글이 없습니다.");
			System.out.println("==========================================");
		} else {
			String delNum = Scan.rl("삭제할 글번호를 입력해주세요.");
			Db.dbExecuteUpdate("delete from "+Db.tableNameBoard+" where n = " + delNum + "");
			System.out.println("삭제완료");
			System.out.println("==========================================");
		}
	}
}
