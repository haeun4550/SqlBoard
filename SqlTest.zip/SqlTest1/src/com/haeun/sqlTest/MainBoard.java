package com.haeun.sqlTest;

import com.haeun.sqlTest.util.Db;
import com.haeun.sqlTest.util.Scan;

public class MainBoard {
	public static void run() {
		Db.dbInit();
		menuList();
	}

	static void menuList() {
		loop: while (true) {
			Db.dbExecuteCount();
			String cmd = Scan.rl("메뉴를 선택해주세요 [1.쓰기/2.읽기/3.리스트/4.수정/5.삭제/e.종료]");
			switch (cmd) {
			case "1":
				ProcWrite.run();
				break;
			case "2":
				ProcRead.run();
				break;
			case "3":
				ProcList.run();
				break;
			case "4":
				ProcUpdate.run();
				break;
			case "5":
				ProcDel.run();
				break;
			case "e":
				break loop;
			}
		}
	}

}