package com.haeun.sqlTest;

import com.haeun.sqlTest.util.Db;
import com.haeun.sqlTest.util.Scan;

public class ProcUpdate {

	public static void run() {
		if (Db.DocCnt == 0) {
			System.out.println("글이 없습니다.");
			System.out.println("===========================================");
		} else {
			String updateNum = Scan.rl("수정할 글번호를 입력해주세요");
			loop: while (true) {
				String cmd = Scan.rl("수정할 정보를 선택해주세요. [1.제목/2.내용/3.작성자/e.수정종료]");
				switch (cmd) {
				case "1":
					String titleUp = Scan.rl("제목을 입력해주세요.");
					Db.dbExecuteUpdate("update "+Db.tableNameBoard+" set title ='" + titleUp + "' where n = " + updateNum + "");
					System.out.println("수정완료");
					System.out.println("===========================================");
					break;
				case "2":
					String contentUp = Scan.rl("내용을 입력해주세요.");
					Db.dbExecuteUpdate("update "+Db.tableNameBoard+" set content ='" + contentUp + "'where n = " + updateNum + "");
					System.out.println("수정완료");
					System.out.println("===========================================");
					break;
				case "3":
					String idUp = Scan.rl("작성자을 입력해주세요.");
					Db.dbExecuteUpdate("update "+Db.tableNameBoard+" set id ='" + idUp + "' where n = " + updateNum + "");
					System.out.println("수정완료");
					System.out.println("===========================================");
					break;
				case "e":
					break loop;
				}
			}
		}
	}
}
